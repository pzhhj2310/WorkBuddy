#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""仓位与止损计算器（新手版）。

根据总资金、买入价、止损价与风险参数，算出建议股数、占用资金、
最大亏损、三档止盈价位，并检查是否触碰风控红线。

用法示例：
    python position_plan.py --capital 50000 --price 12.5 --stop 11.2
    python position_plan.py --capital 50000 --price 12.5 --stop 11.2 --risk-pct 1.5 --max-single-pct 15
    python position_plan.py --capital 100000 --price 8.6 --stop 8.6  # 无止损（应被拦截）

参数默认值对应 references/risk-management.md 的新手规则：
    单笔风险 2%、单票上限 20%、A 股 100 股一手。
"""

import argparse
import sys

RISK_WARN_SINGLE = 0.03   # 单笔风险超过总资金 3% 触发警告
LOT = 100


def fmt(value):
    return "{:,.2f}".format(value)


def main():
    parser = argparse.ArgumentParser(description="仓位与止损计算器")
    parser.add_argument("--capital", type=float, required=True, help="总资金（元）")
    parser.add_argument("--price", type=float, required=True, help="计划买入价")
    parser.add_argument("--stop", type=float, required=True, help="止损价（必须低于买入价）")
    parser.add_argument("--risk-pct", type=float, default=2.0, help="单笔可承受亏损占总资金百分比，默认 2")
    parser.add_argument("--max-single-pct", type=float, default=20.0, help="单票最大仓位百分比，默认 20")
    parser.add_argument("--existing-pct", type=float, default=0.0, help="已持有的该票仓位百分比，默认 0")
    args = parser.parse_args()

    if args.capital <= 0:
        print("总资金必须大于 0")
        return 1
    if args.price <= 0:
        print("买入价必须大于 0")
        return 1
    if args.stop >= args.price:
        print("止损价必须低于买入价。不做止损的仓位不应建立。")
        return 1

    risk_per_share = args.price - args.stop
    risk_amount = args.capital * args.risk_pct / 100.0
    shares_by_risk = risk_amount / risk_per_share

    remaining_pct = max(args.max_single_pct - args.existing_pct, 0.0)
    position_cap = args.capital * remaining_pct / 100.0
    shares_by_cap = position_cap / args.price

    shares = int(min(shares_by_risk, shares_by_cap) // LOT * LOT)

    print("=" * 60)
    print("仓位与止损测算")
    print("=" * 60)
    print("总资金            %s 元" % fmt(args.capital))
    print("买入价 / 止损价   %s / %s" % (fmt(args.price), fmt(args.stop)))
    print("每股风险(R)       %s 元（%.2f%%）" % (
        fmt(risk_per_share), risk_per_share / args.price * 100))
    print("单笔风险预算      %s 元（总资金 %.1f%%）" % (fmt(risk_amount), args.risk_pct))
    print("单票仓位上限      %s 元（%.1f%%）" % (fmt(position_cap), remaining_pct))

    print("-" * 60)
    if shares < LOT:
        print("建议股数          0 股 —— 按当前价格与止损距离，最小一手也超出风险预算")
        print("可选做法：① 放宽资金规模 ② 等更低的买入价 ③ 换标的")
        print("提示：为凑一手而放宽止损，等于放大风险，不建议。")
        return 0

    cost = shares * args.price
    max_loss = shares * risk_per_share
    print("建议股数          %d 股（%d 手）" % (shares, shares // LOT))
    print("占用资金          %s 元（占总资金 %.1f%%）" % (fmt(cost), cost / args.capital * 100))
    print("触发止损时亏损    %s 元（占总资金 %.2f%%）" % (fmt(max_loss), max_loss / args.capital * 100))

    print("-" * 60)
    print("止盈参考（按 R 倍数分批）：")
    for multiple, ratio in ((1.5, "卖出 1/3"), (3.0, "卖出 1/3"), (0, "剩余跟随 20 日线")):
        if multiple == 0:
            print("  移动止盈   跌破 20 日线离场（剩余仓位）")
        else:
            target = args.price + multiple * risk_per_share
            print("  %.1fR       %s 元（%s）" % (multiple, fmt(target), ratio))

    print("-" * 60)
    warnings = []
    if args.risk_pct > RISK_WARN_SINGLE * 100:
        warnings.append("单笔风险超过总资金 3%%，新手建议不超过 2%")
    if args.existing_pct > 0:
        warnings.append("该票已有 %.1f%% 仓位，加仓后请同步上移止损至不亏损位置" % args.existing_pct)
    if cost / args.capital * 100 > 20:
        warnings.append("单票仓位超过 20%，过于集中")
    if risk_per_share / args.price > 0.12:
        warnings.append("止损距离超过 12%%，说明买点离支撑太远，建议等价或缩小仓位")

    if warnings:
        print("风控提醒：")
        for w in warnings:
            print("  ⚠️ " + w)
    else:
        print("风控检查：通过（单笔风险、仓位集中度均在规则内）")

    print("\n下单前自问：买入理由能一句话说清吗？明天跌 5% 我会怎么做？"
          "这笔仓位和前三大持仓是否重复？")
    print("本测算仅为纪律工具，不构成投资建议。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
