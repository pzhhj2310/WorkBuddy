#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""批量股票打分排序（新手筛选器）。

读取 CSV，按 references/screening-rules.md 的规则做硬性过滤与 100 分打分，
输出排名表（Markdown 表格 + 可选 CSV）。

CSV 必需列（缺列会报错提示）：
    code, name, price, market_cap, pe, pb, roe, profit_growth,
    revenue_growth, debt_ratio, turnover

字段说明：
    market_cap      总市值，单位：亿元
    pe              PE(TTM)，亏损填 0 或负数
    pb              PB
    roe             ROE，百分数（15 表示 15%）
    profit_growth   扣非净利润同比增速，百分数
    revenue_growth  营收同比增速，百分数
    debt_ratio      资产负债率，百分数
    turnover        日均成交额，单位：亿元

可选列（用于硬性过滤）：listing_years（上市年数）、pledge_ratio（质押比例，百分数）

用法：
    python screen_stocks.py stocks.csv
    python screen_stocks.py stocks.csv --top 8 --industry-col industry
    python screen_stocks.py stocks.csv --out ranking.csv

注意：本脚本只做机械打分，不构成投资建议。分数高不等于会涨，需配合四维分析。
"""

import argparse
import csv
import sys

REQUIRED = [
    "code", "name", "price", "market_cap", "pe", "pb", "roe",
    "profit_growth", "revenue_growth", "debt_ratio", "turnover",
]

EXCLUDED_KEYWORDS = ("ST", "*ST", "退")


def to_float(value, default=None):
    if value is None:
        return default
    text = str(value).strip().replace(",", "").replace("%", "")
    if text in ("", "-", "--", "None", "nan"):
        return default
    try:
        return float(text)
    except ValueError:
        return default


def band(value, pairs, default=0):
    """pairs 为 (上限, 分数) 列表，按从小到大匹配；value 超过所有上限取 default。"""
    if value is None:
        return 0
    for limit, score in pairs:
        if value <= limit:
            return score
    return default


def score_market_cap(cap):
    if cap is None:
        return 0
    if 20 <= cap <= 100:
        return 20
    if 100 < cap <= 200:
        return 15
    if 200 < cap <= 300:
        return 10
    if 15 <= cap < 20:
        return 8
    if 300 < cap <= 500:
        return 5
    return 0


def score_pe(pe):
    if pe is None or pe <= 0:
        return 0
    return band(pe, [(15, 15), (25, 11), (40, 6), (60, 3)], default=0)


def score_pb(pb):
    if pb is None or pb <= 0:
        return 0
    return band(pb, [(1.5, 10), (3, 6), (6, 3)], default=0)


def score_roe(roe):
    if roe is None:
        return 0
    if roe < 0:
        return 0
    return band(roe, [(6, 3), (10, 7), (15, 11)], default=15)


def score_profit_growth(g):
    if g is None:
        return 0
    if g < -20:
        return 0
    if g < 0:
        return 2
    return band(g, [(15, 7), (30, 11)], default=15)


def score_revenue_growth(g):
    if g is None or g < 0:
        return 0
    return band(g, [(10, 4), (20, 7)], default=10)


def score_debt_ratio(d):
    if d is None:
        return 0
    return band(d, [(40, 10), (60, 6), (70, 3), (80, 1)], default=0)


def score_turnover(t):
    if t is None:
        return 0
    return band(t, [(1, 1), (2, 2), (5, 4)], default=5)


def hard_filter(row, industry_rules):
    """返回淘汰原因列表，空列表表示通过。"""
    reasons = []
    name = str(row.get("name", ""))
    for kw in EXCLUDED_KEYWORDS:
        if kw in name:
            reasons.append("ST/退市风险")
            break

    cap = to_float(row.get("market_cap"))
    if cap is None:
        reasons.append("市值缺失")
    elif cap < 15:
        reasons.append("市值过小 <15亿")
    elif cap > 500:
        reasons.append("市值过大 >500亿")

    pe = to_float(row.get("pe"))
    if pe is not None and pe <= 0:
        reasons.append("PE<=0（亏损）")

    debt = to_float(row.get("debt_ratio"))
    debt_limit = 80.0
    industry = str(row.get("industry", ""))
    if industry in industry_rules:
        debt_limit = industry_rules[industry]
    if debt is not None and debt > debt_limit:
        reasons.append("资产负债率 >%.0f%%" % debt_limit)

    turnover = to_float(row.get("turnover"))
    if turnover is not None and turnover < 0.5:
        reasons.append("日均成交额 <0.5亿（流动性不足）")

    years = to_float(row.get("listing_years"))
    if years is not None and years < 1:
        reasons.append("上市不足1年")

    pledge = to_float(row.get("pledge_ratio"))
    if pledge is not None and pledge > 50:
        reasons.append("质押比例 >50%")

    return reasons


def evaluate(row, industry_rules):
    pe = to_float(row.get("pe"))
    pb = to_float(row.get("pb"))
    roe = to_float(row.get("roe"))
    profit_g = to_float(row.get("profit_growth"))
    revenue_g = to_float(row.get("revenue_growth"))
    debt = to_float(row.get("debt_ratio"))
    turnover = to_float(row.get("turnover"))
    cap = to_float(row.get("market_cap"))

    parts = {
        "市值": score_market_cap(cap),
        "PE": score_pe(pe),
        "PB": score_pb(pb),
        "ROE": score_roe(roe),
        "利润增速": score_profit_growth(profit_g),
        "营收增速": score_revenue_growth(revenue_g),
        "负债率": score_debt_ratio(debt),
        "流动性": score_turnover(turnover),
    }
    return parts, sum(parts.values())


def verdict(total):
    if total >= 75:
        return "重点观察"
    if total >= 60:
        return "观察池"
    if total >= 45:
        return "不主动参与"
    return "回避"


INDUSTRY_DEBT_RULES = {
    "银行": 95.0,
    "保险": 95.0,
    "证券": 90.0,
    "地产": 85.0,
    "建筑": 85.0,
}


def main():
    parser = argparse.ArgumentParser(description="新手股票批量打分排序")
    parser.add_argument("csv_path", help="输入 CSV 路径")
    parser.add_argument("--top", type=int, default=10, help="输出前 N 名，默认 10")
    parser.add_argument("--out", default=None, help="把完整结果写入 CSV")
    args = parser.parse_args()

    try:
        with open(args.csv_path, "r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            rows = list(reader)
    except FileNotFoundError:
        print("找不到文件：%s" % args.csv_path)
        return 1
    except UnicodeDecodeError:
        print("编码错误：请把 CSV 另存为 UTF-8（带或不带 BOM 均可）")
        return 1

    if not rows:
        print("CSV 没有数据行")
        return 1

    missing = [c for c in REQUIRED if c not in rows[0]]
    if missing:
        print("缺少必需列：%s" % ", ".join(missing))
        print("必需列：" + ", ".join(REQUIRED))
        return 1

    passed, dropped = [], []
    for row in rows:
        reasons = hard_filter(row, INDUSTRY_DEBT_RULES)
        if reasons:
            dropped.append((row, reasons))
            continue
        parts, total = evaluate(row, INDUSTRY_DEBT_RULES)
        passed.append({
            "code": row.get("code", ""),
            "name": row.get("name", ""),
            "price": to_float(row.get("price")),
            "market_cap": to_float(row.get("market_cap")),
            "pe": to_float(row.get("pe")),
            "total": total,
            "verdict": verdict(total),
            "parts": parts,
        })

    passed.sort(key=lambda x: x["total"], reverse=True)

    print("=" * 78)
    print("打分结果（共 %d 只通过初筛，%d 只被硬性条件淘汰）" % (len(passed), len(dropped)))
    print("=" * 78)

    header = "| 排名 | 代码 | 名称 | 现价 | 市值(亿) | PE | 得分 | 结论 |"
    print(header)
    print("| --- | --- | --- | --- | --- | --- | --- | --- |")
    for idx, item in enumerate(passed[: args.top], start=1):
        price = "%.2f" % item["price"] if item["price"] is not None else "-"
        cap = "%.0f" % item["market_cap"] if item["market_cap"] is not None else "-"
        pe = "%.1f" % item["pe"] if item["pe"] is not None else "-"
        print("| %d | %s | %s | %s | %s | %s | %d | %s |" % (
            idx, item["code"], item["name"], price, cap, pe, item["total"], item["verdict"]))

    if passed:
        print("\n前三名分项（满分：市值20/PE15/PB10/ROE15/利润15/营收10/负债10/流动性5）：")
        for item in passed[:3]:
            detail = "、".join("%s %d" % (k, v) for k, v in item["parts"].items())
            print("  %s %s：%d 分 → %s" % (item["code"], item["name"], item["total"], detail))

    if dropped:
        print("\n被淘汰（原因）：")
        for row, reasons in dropped[:15]:
            print("  %s %s：%s" % (row.get("code", ""), row.get("name", ""), "；".join(reasons)))
        if len(dropped) > 15:
            print("  …… 其余 %d 只略" % (len(dropped) - 15))

    if args.out and passed:
        with open(args.out, "w", encoding="utf-8-sig", newline="") as fh:
            writer = csv.writer(fh)
            writer.writerow(["code", "name", "price", "market_cap", "pe", "score", "verdict"]
                            + list(passed[0]["parts"].keys()))
            for item in passed:
                writer.writerow([item["code"], item["name"], item["price"], item["market_cap"],
                                 item["pe"], item["total"], item["verdict"]]
                                + list(item["parts"].values()))
        print("\n完整结果已写入：%s" % args.out)

    print("\n提示：分数只是初筛结果，仍需按 references/analysis-checklist.md 做四维分析。"
          "本输出不构成投资建议。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
